#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <sys/stat.h>

#define MAXLAB  2048
#define MAXLINE 256
#define OUTMAX  (64*1024)

typedef struct{ char name[64]; uint32_t addr; } Label;
static Label  labtab[MAXLAB];
static int    labcnt = 0;

static uint8_t  outbuf[OUTMAX];
static uint32_t outpos = 0x1000;   // code start @ 0x1000
static uint32_t entry  = 0;

static void emit(const void *p, int len){
    if(outpos+len > OUTMAX){ fprintf(stderr,"outbuf penuh\n"); exit(1); }
    memcpy(outbuf+outpos, p, len);
    outpos += len;
}
static void emit1(uint8_t x){ emit(&x,1); }
static void emit4(uint32_t x){ emit(&x,4); }

/* ---------- encoder x86-64 mini ---------- */
static void emit_mov_imm64(int reg, uint64_t imm){
    int w=1, r=0, x=0, b=reg>=8;
    if(b) reg-=8;
    emit1(0x40 | (w<<3) | (r<<2) | (x<<1) | b);
    emit1(0xB8 + reg);
    emit(&imm,8);
}
static void emit_syscall(void){
    emit1(0x0F); emit1(0x05);
}

/* ---------- parser ---------- */
static char line[MAXLINE];
static char *tok;
static char *skipsp(char *s){ while(*s && isspace(*s))++s; return s; }
static char *token(char *s){
    s=skipsp(s);
    if(!*s){ tok=NULL; return s; }
    char *d=s;
    if(isalpha(*s)||*s=='_'){
        while(isalnum(*s)||*s=='_') ++s;
    }else if(*s=='"'){
        for(d=++s; *s && *s!='"'; ++s) ;
        *s++=0;
        tok=d; return s;
    }else{
        ++s;
    }
    *s=0; tok=d; return s;
}
static uint32_t findlab(const char *name){
    for(int i=0;i<labcnt;i++)
        if(!strcmp(labtab[i].name,name)) return labtab[i].addr;
    fprintf(stderr,"label %s tidak ditemukan\n",name); exit(1);
}

/* ---------- pass1: kumpulkan label ---------- */
static void pass1(FILE *f){
    uint32_t here = outpos;
    while(fgets(line,sizeof(line),f)){
        char *s=line;
        s=token(s); if(!tok) continue;
        if(tok[strlen(tok)-1]==':'){        // LABEL:
            tok[strlen(tok)-1]=0;
            strcpy(labtab[labcnt].name, tok);
            labtab[labcnt].addr = here;
            labcnt++;
            continue;
        }
        if(!strcmp(tok,".masuk")){
            s=token(s); entry = findlab(tok); continue;
        }
        if(!strcmp(tok,".tulis")){
            s=token(s);
            int len = strlen(tok);
            strcpy((char*)(outbuf+here), tok);
            here += len;
            continue;
        }
        if(!strcmp(tok,"KELUAR")){ here += 2; continue; }
        if(!strcmp(tok,"DSQ"))   { here += 1; continue; }
        if(!strcmp(tok,"MUAT"))  { here += 3; continue; }
    }
}

/* ---------- pass2: encode ---------- */
static void pass2(FILE *f){
    uint32_t here = outpos;
    rewind(f);
    while(fgets(line,sizeof(line),f)){
        char *s=line;
        s=token(s); if(!tok) continue;
        if(tok[strlen(tok)-1]==':') continue;
        if(!strcmp(tok,".masuk")||!strcmp(tok,".tulis")) continue;

        if(!strcmp(tok,"KELUAR")){ emit_syscall(); continue; }
        if(!strcmp(tok,"DSQ"))   { emit1(0x90); continue; }
        if(!strcmp(tok,"MUAT")){
            s=token(s); int dst = tok[0]-'A';
            s=token(s); uint64_t imm = strtoull(tok,NULL,0);
            emit_mov_imm64(dst, imm);
            continue;
        }
    }
}

/* ---------- tulis ELF64 ---------- */
static void write_elf(const char *path){
    FILE *f = fopen(path,"wb");
    if(!f){ perror(path); exit(1); }
    uint8_t ehdr[]={
        0x7f,'E','L','F', 2,1,1,0, 0,0,0,0,0,0,0,0,
        0x62,0x3e,1,0, 0,0,0,0,0,0,0,0,0,0,0,0,
        0x78,0x00,0x40,0x00,0x00,0x00,0x00,0x00,
        0,0,0,0, 0,0,0,0,
        0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0,0,0,0, 0,0,0,0,
        0x01|0x02,0x00,0x3e,0x00,
        0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0,0,0,0,0,0,0,0,
        0,0,0,0,0,0,0,0,
        0x00,0x10,0x00,0x00,0x00,0x00,0x00,0x00,
        0,0,0,0,0x40,0x00,
        0x38,0x00,0x01,0x00,0x00,0x00,0x00,0x00
    };
    *(uint64_t*)(ehdr+24) = entry;
    fwrite(ehdr,1,64,f);
    uint8_t phdr[56]={0};
    *(uint32_t*)(phdr+0)  = 1;
    *(uint64_t*)(phdr+8)  = 0x1000;
    *(uint64_t*)(phdr+16) = 0x1000;
    *(uint64_t*)(phdr+32) = outpos;
    *(uint64_t*)(phdr+40) = outpos;
    *(uint64_t*)(phdr+48) = 7;
    fwrite(phdr,1,56,f);
    fwrite(outbuf+0x1000,1,outpos-0x1000,f);
    fclose(f);
    chmod(path,0755);
}

int main(int c,char **v){
    if(c!=2){ fprintf(stderr,"pakai: %s file.gpn\n",v[0]); return 1; }
    FILE *f = fopen(v[1],"r");
    if(!f){ perror(v[1]); return 1; }
    pass1(f);
    pass2(f);
    fclose(f);
    write_elf("a.out");
    printf("gapnain: selesai, output -> a.out (%u byte)\n",outpos);
    return 0;
}
